library(testthat)
library(dhisextractr)

test_check("dhisextractr")
